
namespace SnobotSimHal
{
    extern const char* Version;
}
