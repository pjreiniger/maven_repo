

namespace StackTraceHelper
{
    void PrintStackTracker();
}
