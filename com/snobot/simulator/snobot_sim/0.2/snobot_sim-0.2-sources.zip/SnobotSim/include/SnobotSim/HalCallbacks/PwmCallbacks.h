
#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
    EXPORT_ void InitializePwmCallbacks();
    EXPORT_ void ResetPwmCallbacks();
}
