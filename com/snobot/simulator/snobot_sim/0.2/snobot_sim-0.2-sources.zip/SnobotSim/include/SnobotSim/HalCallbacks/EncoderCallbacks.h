
#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
    EXPORT_ void InitializeEncoderCallbacks();
    EXPORT_ void ResetEncoderCallbacks();
}
