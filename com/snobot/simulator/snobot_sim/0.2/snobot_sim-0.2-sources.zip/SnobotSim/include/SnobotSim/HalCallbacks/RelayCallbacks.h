
#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
    EXPORT_ void InitializeRelayCallbacks();
    EXPORT_ void ResetRelayCallbacks();
}
