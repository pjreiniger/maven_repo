/*
 * ISimulatorUpdater.hpp
 *
 *  Created on: May 7, 2017
 *      Author: PJ
 */

#pragma once
class ISimulatorUpdater
{
public:
    virtual void Update() = 0;
};
