
#pragma once

#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
EXPORT_ void InitializeSolenoidCallbacks();
EXPORT_ void ResetSolenoidCallbacks();
} // namespace SnobotSim
