/*
 * ISimulatorUpdater.hpp
 *
 *  Created on: May 7, 2017
 *      Author: PJ
 */

#ifndef ISIMULATORUPDATER_HPP_
#define ISIMULATORUPDATER_HPP_


class ISimulatorUpdater
{
public:

    virtual void Update() = 0;
};


#endif /* ISIMULATORUPDATER_HPP_ */
