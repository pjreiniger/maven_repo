

namespace StackTraceHelper
{
	void PrintStackTracker();
}
