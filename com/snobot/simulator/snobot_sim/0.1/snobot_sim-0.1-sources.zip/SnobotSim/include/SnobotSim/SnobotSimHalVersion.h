
#include "SnobotSim/ExportHelper.h"

namespace SnobotSim
{
    EXPORT_ const char* GetSnobotSimVersion();


}
