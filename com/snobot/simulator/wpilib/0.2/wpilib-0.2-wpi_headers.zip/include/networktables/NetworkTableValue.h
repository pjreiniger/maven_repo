/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2015. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#ifndef NT_VALUE_H_
#define NT_VALUE_H_

#include <cassert>
#include <memory>
#include <string>
#include <type_traits>
#include <vector>

#include "llvm/ArrayRef.h"
#include "llvm/StringRef.h"

#include "ntcore_c.h"

namespace nt {

using llvm::ArrayRef;
using llvm::StringRef;

/**
 * A network table entry value.
 */
class Value final {
  struct private_init {};

 public:
  Value();
  Value(NT_Type type, unsigned long long time, const private_init&);
  ~Value();

  /**
   * Get the data type.
   * @return The type.
   */
  NT_Type type() const { return m_val.type; }

  /**
   * Get the data value stored.
   * @return The type.
   */
  const NT_Value& value() const { return m_val; }

  /**
   * Get the creation time of the value.
   * @return The time, in the units returned by nt::Now().
   */
  unsigned long long last_change() const { return m_val.last_change; }

  /**
   * Get the creation time of the value.
   * @return The time, in the units returned by nt::Now().
   */
  unsigned long long time() const { return m_val.last_change; }

  /**
   * @defgroup TypeCheckers Type Checkers
   * @{
   */

  /**
   * Determine if entry value contains a value or is unassigned.
   * @return True if the entry value contains a value.
   */
  bool IsValid() const { return m_val.type != NT_UNASSIGNED; }

  /**
   * Determine if entry value contains a boolean.
   * @return True if the entry value is of boolean type.
   */
  bool IsBoolean() const { return m_val.type == NT_BOOLEAN; }

  /**
   * Determine if entry value contains a double.
   * @return True if the entry value is of double type.
   */
  bool IsDouble() const { return m_val.type == NT_DOUBLE; }

  /**
   * Determine if entry value contains a string.
   * @return True if the entry value is of string type.
   */
  bool IsString() const { return m_val.type == NT_STRING; }

  /**
   * Determine if entry value contains a raw.
   * @return True if the entry value is of raw type.
   */
  bool IsRaw() const { return m_val.type == NT_RAW; }

  /**
   * Determine if entry value contains a rpc definition.
   * @return True if the entry value is of rpc definition type.
   */
  bool IsRpc() const { return m_val.type == NT_RPC; }

  /**
   * Determine if entry value contains a boolean array.
   * @return True if the entry value is of boolean array type.
   */
  bool IsBooleanArray() const { return m_val.type == NT_BOOLEAN_ARRAY; }

  /**
   * Determine if entry value contains a double array.
   * @return True if the entry value is of double array type.
   */
  bool IsDoubleArray() const { return m_val.type == NT_DOUBLE_ARRAY; }

  /**
   * Determine if entry value contains a string array.
   * @return True if the entry value is of string array type.
   */
  bool IsStringArray() const { return m_val.type == NT_STRING_ARRAY; }

  /** @} */

  /**
   * @defgroup TypeSafeGetters Type-Safe Getters
   * @{
   */

  /**
   * Get the entry's boolean value.
   * @return The boolean value.
   */
  bool GetBoolean() const {
    assert(m_val.type == NT_BOOLEAN);
    return m_val.data.v_boolean != 0;
  }

  /**
   * Get the entry's double value.
   * @return The double value.
   */
  double GetDouble() const {
    assert(m_val.type == NT_DOUBLE);
    return m_val.data.v_double;
  }

  /**
   * Get the entry's string value.
   * @return The string value.
   */
  StringRef GetString() const {
    assert(m_val.type == NT_STRING);
    return m_string;
  }

  /**
   * Get the entry's raw value.
   * @return The raw value.
   */
  StringRef GetRaw() const {
    assert(m_val.type == NT_RAW);
    return m_string;
  }

  /**
   * Get the entry's rpc definition value.
   * @return The rpc definition value.
   */
  StringRef GetRpc() const {
    assert(m_val.type == NT_RPC);
    return m_string;
  }

  /**
   * Get the entry's boolean array value.
   * @return The boolean array value.
   */
  ArrayRef<int> GetBooleanArray() const {
    assert(m_val.type == NT_BOOLEAN_ARRAY);
    return ArrayRef<int>(m_val.data.arr_boolean.arr,
                         m_val.data.arr_boolean.size);
  }

  /**
   * Get the entry's double array value.
   * @return The double array value.
   */
  ArrayRef<double> GetDoubleArray() const {
    assert(m_val.type == NT_DOUBLE_ARRAY);
    return ArrayRef<double>(m_val.data.arr_double.arr,
                            m_val.data.arr_double.size);
  }

  /**
   * Get the entry's string array value.
   * @return The string array value.
   */
  ArrayRef<std::string> GetStringArray() const {
    assert(m_val.type == NT_STRING_ARRAY);
    return m_string_array;
  }

  /** @} */

  /**
   * @defgroup Factories Factory functions
   * @{
   */

  /**
   * Creates a boolean entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeBoolean(bool value,
                                            unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_BOOLEAN, time, private_init());
    val->m_val.data.v_boolean = value;
    return val;
  }

  /**
   * Creates a double entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeDouble(double value,
                                           unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_DOUBLE, time, private_init());
    val->m_val.data.v_double = value;
    return val;
  }

  /**
   * Creates a string entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeString(StringRef value,
                                           unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_STRING, time, private_init());
    val->m_string = value;
    val->m_val.data.v_string.str = const_cast<char*>(val->m_string.c_str());
    val->m_val.data.v_string.len = val->m_string.size();
    return val;
  }

  /**
   * Creates a string entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
#ifdef _MSC_VER
  template <typename T,
            typename = std::enable_if_t<std::is_same<T, std::string>>>
#else
  template <typename T,
            typename std::enable_if<std::is_same<T, std::string>::value>::type>
#endif
  static std::shared_ptr<Value> MakeString(T&& value,
                                           unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_STRING, time, private_init());
    val->m_string = std::move(value);
    val->m_val.data.v_string.str = const_cast<char*>(val->m_string.c_str());
    val->m_val.data.v_string.len = val->m_string.size();
    return val;
  }

  /**
   * Creates a raw entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeRaw(StringRef value,
                                        unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_RAW, time, private_init());
    val->m_string = value;
    val->m_val.data.v_raw.str = const_cast<char*>(val->m_string.c_str());
    val->m_val.data.v_raw.len = val->m_string.size();
    return val;
  }

  /**
   * Creates a raw entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
#ifdef _MSC_VER
  template <typename T,
            typename = std::enable_if_t<std::is_same<T, std::string>>>
#else
  template <typename T,
            typename std::enable_if<std::is_same<T, std::string>::value>::type>
#endif
  static std::shared_ptr<Value> MakeRaw(T&& value,
                                        unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_RAW, time, private_init());
    val->m_string = std::move(value);
    val->m_val.data.v_raw.str = const_cast<char*>(val->m_string.c_str());
    val->m_val.data.v_raw.len = val->m_string.size();
    return val;
  }

  /**
   * Creates a rpc entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeRpc(StringRef value,
                                        unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_RPC, time, private_init());
    val->m_string = value;
    val->m_val.data.v_raw.str = const_cast<char*>(val->m_string.c_str());
    val->m_val.data.v_raw.len = val->m_string.size();
    return val;
  }

  /**
   * Creates a rpc entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  template <typename T>
  static std::shared_ptr<Value> MakeRpc(T&& value,
                                        unsigned long long time = 0) {
    auto val = std::make_shared<Value>(NT_RPC, time, private_init());
    val->m_string = std::move(value);
    val->m_val.data.v_raw.str = const_cast<char*>(val->m_string.c_str());
    val->m_val.data.v_raw.len = val->m_string.size();
    return val;
  }

  /**
   * Creates a boolean array entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeBooleanArray(ArrayRef<int> value,
                                                 unsigned long long time = 0);

  /**
   * Creates a double array entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeDoubleArray(ArrayRef<double> value,
                                                unsigned long long time = 0);

  /**
   * Creates a string array entry value.
   * @param value the value
   * @param time if nonzero, the creation time to use (instead of the current
   *             time)
   * @return The entry value
   */
  static std::shared_ptr<Value> MakeStringArray(ArrayRef<std::string> value,
                                                unsigned long long time = 0);

  // Note: This function moves the values out of the vector.
  static std::shared_ptr<Value> MakeStringArray(
      std::vector<std::string>&& value, unsigned long long time = 0);

  /** @} */

  Value(const Value&) = delete;
  Value& operator=(const Value&) = delete;
  friend bool operator==(const Value& lhs, const Value& rhs);

 private:
  NT_Value m_val;
  std::string m_string;
  std::vector<std::string> m_string_array;
};

bool operator==(const Value& lhs, const Value& rhs);
inline bool operator!=(const Value& lhs, const Value& rhs) {
  return !(lhs == rhs);
}

/** NetworkTable Value alias for similarity with Java. */
typedef Value NetworkTableValue;

}  // namespace nt

#endif  // NT_VALUE_H_
