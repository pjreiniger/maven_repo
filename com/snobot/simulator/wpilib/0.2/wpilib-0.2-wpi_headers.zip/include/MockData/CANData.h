/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "NotifyListener.h"
#include "HAL/CAN.h"

#ifdef __cplusplus
extern "C" {
#endif

void HALSIM_ResetCAN();

/////////////////////////////////////////
// Send Message
/////////////////////////////////////////
int32_t HALSIM_RegisterCANSendMessageCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify);
void HALSIM_CancelCANSendMessageCallback(int32_t index, int32_t uid);

/////////////////////////////////////////
// Receive Message
/////////////////////////////////////////
int32_t HALSIM_RegisterCANReceiveMessageCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify);
void HALSIM_CancelCANReceiveMessageCallback(int32_t index, int32_t uid);

/////////////////////////////////////////
// Open Stream Session
/////////////////////////////////////////
int32_t HALSIM_RegisterCANOpenStreamSessionCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify);
void HALSIM_CancelCANOpenStreamSessionCallback(int32_t index, int32_t uid);


/////////////////////////////////////////
// Close Stream Session
/////////////////////////////////////////
int32_t HALSIM_RegisterCANCloseStreamSessionCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify);
void HALSIM_CancelCANCloseStreamSessionCallback(int32_t index, int32_t uid);


/////////////////////////////////////////
// Read Stream Session
/////////////////////////////////////////
int32_t HALSIM_RegisterCANReadStreamSessionCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify);
void HALSIM_CancelCANReadStreamSessionCallback(int32_t index, int32_t uid);


/////////////////////////////////////////
// Get CAN Status
/////////////////////////////////////////
int32_t HALSIM_RegisterCANGetCANStatusCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify);
void HALSIM_CancelCANGetCANStatusCallback(int32_t index, int32_t uid);


/////////////////////////////////////////
// Getters
/////////////////////////////////////////
void HALSIM_GetCANLastSentMessageData(uint8_t* buffer, int32_t count);
void HALSIM_SetCANValueForRead(uint8_t* buffer, int32_t count);
void HALSIM_SetCANMessagesForReadStream(struct HAL_CANStreamMessage* messages, int32_t count);


#ifdef __cplusplus
}
#endif
