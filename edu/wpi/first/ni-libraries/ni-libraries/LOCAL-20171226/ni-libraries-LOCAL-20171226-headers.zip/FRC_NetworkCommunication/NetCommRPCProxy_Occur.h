#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void NetCommRPCProxy_SetOccurFuncPointer(void (*Occur)(uint32_t));

#ifdef __cplusplus
}
#endif
