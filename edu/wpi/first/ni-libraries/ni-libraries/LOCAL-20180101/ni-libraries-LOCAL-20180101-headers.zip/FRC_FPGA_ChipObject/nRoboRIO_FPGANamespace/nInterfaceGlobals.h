// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __nFRC_2018_18_0_8_nInterfaceGlobals_h__
#define __nFRC_2018_18_0_8_nInterfaceGlobals_h__

namespace nFPGA
{
namespace nFRC_2018_18_0_8
{
   extern unsigned int g_currentTargetClass;

   static const int g_SpiAutoData_index = 0;
   static const int g_DMA_index = 1;
}
}

#endif // __nFRC_2018_18_0_8_nInterfaceGlobals_h__
